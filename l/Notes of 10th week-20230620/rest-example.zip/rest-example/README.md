REST API
REPRESENTATIONAL STATE TRANSFER API
architecture style
specification

resource -> url


traditional
soap (simple object access protocol)

HTTP METHOD (ACTION)
1. get
2. Post
3. PUT/patch
4. DELETE


REST API SPEC
